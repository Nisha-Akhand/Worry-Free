import { initializeApp } from "firebase/app";
var firebaseConfig = {
  apiKey: "AIzaSyBSIRCzFrqc4m9ASnQZP0TH6U3j5rYob34",
  authDomain: "worryfree-6d9b2.firebaseapp.com",
  databaseURL: "https://worryfree-6d9b2-default-rtdb.firebaseio.com",
  projectId: "worryfree-6d9b2",
  storageBucket: "worryfree-6d9b2.appspot.com",
  messagingSenderId: "490740966458",
  appId: "1:490740966458:web:58ab36fc4c25c701454103",
  measurementId: "G-4T0DBY48XM"
};

const app = initializeApp(firebaseConfig);
firebase.auth.Auth.Persistence.LOCAL;

$("#login2").click(function(){
  var email = $("#email").val();
  var pass = $("#pass").val();
  const auth=getAuth(firebaseApp);

  if(email!= "" && pass != "")
  {
    firebase.auth().signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      alert("loged in");
      var user = userCredential.user;
    })
    .catch((error) => {
      var errorCode = error.code;
      var errorMessage = error.message;
      console.log(errorCode);
      console.log(errorMessage);
      window.alert("Message : "+ errorMessage);
    });
  }
  else{
    window.alert("Form is incomplete. Please fill out all fields");
  }
});




function changeimg_1(){
    var image=document.getElementById("images_1");
    var b1=document.getElementById("sps_1");
    if(image.src.match("assets/img/bulboff.png")){
      image.src="assets/img/bulbon1.png";
      b1.style.boxShadow="0px 0px 20px yellow";
    }
    else{
      image.src="assets/img/bulboff.png";
      b1.style.boxShadow=null;
    }
  }
  function changeimg_2(){
    var image=document.getElementById("images_2");
    var b2=document.getElementById("sps_2");
    if(image.src.match("assets/img/fanstop.png")){
      image.src="assets/img/fan.gif";
      b2.style.boxShadow="0px 0px 20px aqua";
    }
    else{
      image.src="assets/img/fanstop.png";
      b2.style.boxShadow=null;
    }
  }
  function changeimg_3(){
    var image=document.getElementById("images_3");
    var b3=document.getElementById("sps_3");
    if(image.src.match("assets/img/TV1.jpg")){
      image.src="assets/img/16714-graphs-in-tv.gif";
      b3.style.boxShadow="0px 0px 20px aqua";
    }
    else{
      image.src="assets/img/TV1.jpg";
      b3.style.boxShadow=null;
    }}
    function changeimg_4(){
    var image=document.getElementById("images_4");
    var b4=document.getElementById("sps_4");
    if(image.src.match("assets/img/ACoff.PNG")){
      image.src="assets/img/ACon.png";
      b4.style.boxShadow="0px 0px 20px aqua";
    }
    else{
      image.src="assets/img/ACoff.PNG";
      b4.style.boxShadow=null;
    }
  }
  function changeimg_5(){
    var image=document.getElementById("images_5");
    var b3=document.getElementById("sps_5");
    if(image.src.match("assets/img/Oven.png")){
      image.src="assets/img/Oven.gif";
      b3.style.boxShadow="0px 0px 20px aqua";
    }
    else{
      image.src="assets/img/Oven.png";
      b3.style.boxShadow=null;
    }}